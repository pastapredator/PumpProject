var Starter = require('../models/starter');
var config = require('../../config');

// create a starter (accessed at POST http://localhost:8080/api/starter)
exports.create = function(req, res) {

    // create a new instance of the starer model
    var starter = new Starter(req.body);

    // save the user and check for errors
    starter.save(function(err) {
        if(err) {
            // duplicate entry
            console.log(err);
            return res.send(err);
        }
        res.json({ message: 'Starter Data Saved!'});
    });
};

// get all the users (accessed at GET http://localhost:8080/api/users) // ... /api/starter
exports.list = function(req, res) {

    Starter.find(function(err,starter) {
        if (err) res.send(err);
        //return the starters
        res.json(starter);
    });
};

// on routes that end in /users/:user_id


// get the user with that id
// (accessed at GET http://localhost:8080/api/users/:user_id)
exports.listOne = function(req, res) {
    Starter.findById(req.params.starter_id, function(err, starter) {
        if(err) res.send(err);

        // return that user
        res.json(starter);
    });
};

exports.listSearch = function(req, res) {

    req.body.type = 'Starter';

    var reqHP = req.body.body.hp;
    var reqvol = req.body.body.voltage;
    var reqCurr = req.body.body.current;
    // var reqCost = req.body.body.cost;


    var query = Starter.find({"body.hp": reqHP, "body.voltage":reqvol,
        "body.current":reqCurr });


    var final = [];

    query.exec(function(err, starter) {
        if(err) {
            res.send(err);
            res.json({message: 'Starter not found!'});
        }
        /*
        for(var k in starter)
        {
            var C = starter[k].properties.Curr;
            var hp = starter[k].properties.HP;

            var tempIndexOfD = C.length-1;
            var i;
            var flag = 0;
            for(i = 0; i<C.Curr; i++){
                if(D[i]>=reqCurr) {
                    if(hp[i]>=reqHP) {
                        final.push(starter[k])
                        flag = 1;
                        break;
                    }
                }
            }
        }*/
        // final.push(starter[k])
        // return that user
        res.json(starter);
        console.log(starter);

    });
};

// update the user with this id
// (accessed at PUT http://localhost:8080/api/users/:user_id)
exports.update = function(req, res){


    // use our starter model to find the starter we want
    Starter.findById(req.params.starter_id, function(err, starter) {

        if(err) res.send(err);


        if(req.body.hp)starter.hp = req.body.hp;
        if(req.body.voltage)starter.vol= req.body.voltage;
        if(req.body.current)starter.current = req.body.current;
        if(req.body.cost)starter.cost = req.body.cost;

        // save the starter
        starter.save(function(err) {
            if(err) res.send(err);

            //return a message
            res.json({ message: 'Starter updated!'});
        });
    });
};
// delete the user with this id
// (accessed at DELETE http://localhost:8080/api/users/:user_id)
exports.remove = function(req, res) {
    Starter.remove({
        _id: req.params.starter_id
    }, function(err, starter) {
        if(err) return res.send(err);

        res.json({ message: 'Successfully deleted'});
    });
};


