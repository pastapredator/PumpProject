var Pump = require('../models/pump');
var config = require('../../config');

// create a user (accessed at POST http://localhost:8080/api/users)
exports.create = function(req, res) {

    // create a new instance of the User model
    var pump = new Pump(req.body);

   // save the user and check for errors
    pump.save(function(err) {
        if(err) {
            // duplicate entry
            console.log(err);
            return res.send(err);
        }
        res.json({ message: 'Pump Data Saved!'});
    });
};

// get all the users (accessed at GET http://localhost:8080/api/users)
exports.list = function(req, res) {

    Pump.find(function(err,pumps) {
        if (err) res.send(err);
        //return the users
        res.json(pumps);
    });
};

// on routes that end in /users/:user_id


// get the user with that id
// (accessed at GET http://localhost:8080/api/users/:user_id)
exports.listOne = function(req, res) {
    Pump.findById(req.params.pump_id, function(err, pump) {
        if(err) res.send(err);

        // return that user
        res.json(pump);
    });
};

exports.listSearch = function(req, res) {

    console.log(req.body);

    req.body.properties.type = 'Pump';

    /*Total Head calc  frictional losses yet to be accounted*/

    var reqPO = req.body.properties.pumpOutlet; // HP to meter - conversion needed ?
    var reqEH = req.body.properties.extraHeight;
    var reqRP = req.body.properties.ratedPower;
    var reqHH = req.body.properties.headHeight_supported + reqEH+ reqPO; // assuming EH, PO is in meters
    var reqWD = req.body.properties.waterDischarge;

    var query = Pump.find({"properties.ratedPower":{$gte:reqRP}, "properties.waterDischarge":{$gte:reqWD},
        "properties.headHeight_supported":{$gte:reqHH}
    });

    var final = [];

    query.exec(function(err, pumps) {
        if(err) {
            res.send(err);
            res.json({message: 'Pumps not found!'});
        }

        for(var k in pumps)
        {
            var wd = pumps[k].properties.waterDischarge;
            var hh = pumps[k].properties.headHeight_supported;

            var tempIndexOfWD = wd.length-1;
            var i;
            var flag = 0;
            for(i = 0; i<wd.length; i++){
                if(wd[i]>=reqWD) {
                    if(hh[i]>=reqHH) {
                        final.push(pumps[k])
                        flag = 1;
                        break;
                    }
                }
            }
        }
        // return that user
        res.json(final);

    });
};

// update the user with this id
// (accessed at PUT http://localhost:8080/api/users/:user_id)
exports.update = function(req, res){

    // use our pump model to find the pump we want
    Pump.findById(req.params.pump_id, function(err, pump) {

        if(err) res.send(err);

        if(req.body.company) pump.company = req.body.company;
        if(req.body.productName) pump.productName = req.body.productName;
        if(req.body.shopName) pump.shopName = req.body.shopName;
        if(req.body.phNo1) pump.phNo1 = req.body.phNo1;
        if(req.body.phNo2) pump.phNo2 = req.body.phNo2;
        if(req.body.mobile) pump.mobile = req.body.mobile;
        if(req.body.properties.ratedPower) pump.properties.ratedPower = req.body.properties.ratedPower;
        if(req.body.properties.noOfStages_supported) pump.properties.noOfStages_supported = req.body.properties.noOfStages_supported;
        if(req.body.properties.headHeight_supported) pump.properties.headHeight_supported = req.body.properties.headHeight_supported;
        if(req.body.properties.waterDischarge) pump.properties.waterDischarge = req.body.properties.waterDischarge;
        if(req.body.properties.outlet) pump.properties.outlet = req.body.properties.outlet;
        if(req.body.properties.cost) pump.properties.cost = req.body.properties.cost;

        // save the pump
        pump.save(function(err) {
            if(err) res.send(err);

            //return a message
            res.json({ message: 'Pump updated!'});
        });
    });
};
// delete the user with this id
// (accessed at DELETE http://localhost:8080/api/users/:user_id)
exports.remove = function(req, res) {
    Pump.remove({
        _id: req.params.pump_id
    }, function(err, pump) {
        if(err) return res.send(err);

        res.json({ message: 'Successfully deleted'});
    });
};

// test route to make sure everything is working
// accessed at GET http://localhost:8080/api


// more routes for our API will happen here

/**
 * Created by CES-ANRC-3 on 04-May-16.
 */
