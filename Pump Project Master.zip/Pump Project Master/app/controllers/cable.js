var Cable = require('../models/cable'); // Change var Pump to Cable [ in everything that is to follow cable <-- pump]
var config = require('../../config');

// create a user (accessed at POST http://localhost:8080/api/users)
exports.create = function(req, res) {

    // create a new instance of the User model
    var cable = new Cable(req.body);

    // save the user and check for errors
    cable.save(function(err) {
        if(err) {
            // duplicate entry
            console.log(err);
            return res.send(err);
        }
        res.json({ message: 'Cable Data Saved!'});
    });
};

// get all the users (accessed at GET http://localhost:8080/api/users) // ... /api/cable  #is it cable or cables ?
exports.list = function(req, res) {

    Cable.find(function(err,cable) {
        if (err) res.send(err);
        //return the users
        res.json(cable);
    });
};

// on routes that end in /users/:user_id


// get the user with that id
// (accessed at GET http://localhost:8080/api/users/:user_id)
exports.listOne = function(req, res) {
    Cable.findById(req.params.cable_id, function(err, cable) {
        if(err) res.send(err);

        // return that user
        res.json(cable);
    });
};

exports.listSearch = function(req, res) {

    console.log(req.body);


    req.body.type = 'Cable';

    var reqHP = req.body.body.hp;
    var reqLen = req.body.body.length;
    var reqDia = req.body.body.diameter;
    var reqVol = req.body.body.voltage;
    var reqCost = req.body.body.cost;

  /*  var query = Cable.find({ "body.hp" :reqHP, "body.length" :reqLen,
        "body.diameter" :reqDia,"body.voltage" :reqVol
    });
*/

   var query = Cable.find({"body.hp" : reqHP, "body.length" : reqLen,
       "body.diameter" : reqDia, "body.voltage" : reqVol});



    query.exec(function(err, cable) {
        console.log('in find method')
        if(err) {
            res.send(err);
            res.json({message: 'Cable not found!'});
        }


        // return that user
        console.log(cable);
        res.json(cable);

    });
};


// (accessed at PUT http://localhost:8080/api/users/:user_id)
exports.update = function(req, res){


    // use our pump model to find the pump we want
    Cable.findById(req.params.cable_id, function(err, cable) {

        if(err) res.send(err);


        if(req.body.hp)cable.hp = req.body.hp;
        if(req.body.length)cable.length = req.body.length;
        if(req.body.diameter)cable.diameter = req.body.diameter;
        if(req.body.voltage)cable.voltage = req.body.voltage;
        if(req.body.cost)cable.cost = req.body.cost;

        // save the cable
        cable.save(function(err) {
            if(err) res.send(err);

            //return a message
            res.json({ message: 'Cable updated!'});
        });
    });
};
// delete the user with this id
// (accessed at DELETE http://localhost:8080/api/users/:user_id)
exports.remove = function(req, res) {
    Cable.remove({
        _id: req.params.cable_id
    }, function(err, cable) {
        if(err) return res.send(err);

        res.json({ message: 'Successfully deleted'});
    });
};


