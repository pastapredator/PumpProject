var User = require('../models/user');
var config = require('../../config');

// on routes that end in /users
// ----------------------------------------------------

    // create a user (accessed at POST http://localhost:8080/api/users)
    exports.create = function(req, res) {

        // create a new instance of the User model
        var user = new User();

        // set the users information (comes from the request)
        user.name = req.body.name;
        user.username = req.body.username;
        user.password = req.body.password;

        // save the user and check for errors
        user.save(function(err) {
            if(err) {
                // duplicate entry
                if(err.code == 11000)
                    return res.json({ success: false, message: 'A user with that username already exists. '});
                else
                    return res.send(err);
            }
            res.json({ message: 'User created!'});
        });
    };

    // get all the users (accessed at GET http://localhost:8080/api/users)
    exports.list = function(req, res) {
        User.find(function(err, users) {
            if(err) res.send(err);

            //return the users
            res.json(users);
        });
    };

// on routes that end in /users/:user_id


    // get the user with that id
    // (accessed at GET http://localhost:8080/api/users/:user_id)
    exports.listOne = function(req, res) {
        User.findById(req.params.user_id, function(err, user) {
            if(err) res.send(err);

            // return that user
            res.json(user);
        });
    };

    // update the user with this id
    // (accessed at PUT http://localhost:8080/api/users/:user_id)
    exports.update = function(req, res){

        // use our user model to find the user we want
        User.findById(req.params.user_id, function(err, user) {

            if(err) res.send(err);

            // update the users info only if its new
            if(req.body.name) user.name = req.body.name;
            if(req.body.username) user.username = req.body.username;
            if(req.body.password) user.password = req.body.password;

            // save the user
            user.save(function(err) {
                if(err) res.send(err);

                //return a message
                res.json({ message: 'User updated!'});
            });
        });
    };
    // delete the user with this id
    // (accessed at DELETE http://localhost:8080/api/users/:user_id)
    exports.remove = function(req, res) {
        User.remove({
            _id: req.params.user_id
        }, function(err, user) {
            if(err) return res.send(err);

            res.json({ message: 'Successfully deleted'});
        });
    };

// test route to make sure everything is working
// accessed at GET http://localhost:8080/api


// more routes for our API will happen here

/**
 * Created by CES-ANRC-3 on 04-May-16.
 */
