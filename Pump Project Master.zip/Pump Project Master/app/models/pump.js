// grab the packages that we need for the user model
var mongoose = require('mongoose');
var schema = mongoose.Schema;

// pump schema
var PumpSchema = new schema({
    "company" : {
        type: String
    },
    "productName" : {
        type: String

    },
    "shopName" : {
        type: String
    },
    "phNo1" : {
        type: String
    },
    "phNo2" : {
        type: String
    },
    "mobile" : {
        type: String
    },
    "properties" : {
        "ratedPower" : {
            type: Number
        },
        "noOfStages_supported" :{
            type: Number
        },
        "headHeight_supported" : {
            type: [Number]
        },
        "waterDischarge" : {
            type: [Number]
        },
        "outlet" : {
            type: Number
        },
        "cost" : {
            type: Number
        },
        "type" : {
            type: String,
            default: "Pump"
        }
    }
});

// hash the password before the user is saved


//return the model
module.exports = mongoose.model('Pump', PumpSchema);