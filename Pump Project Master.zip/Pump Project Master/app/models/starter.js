/**
 * Created by Krishna on 10/24/2016.
 */
// grab the packages that we need for the user model
var mongoose = require('mongoose');
var schema = mongoose.Schema;

// starter schema
var StarterSchema = new schema({
    "body" :{
        "hp": {
            type: Number
        },
        "voltage": {
            type: Number
        },
        "current": {
            type: Number
        },
        "cost":
        {
            type : Number
        },
        "type": {
            type: String,
            default: "Starter"
        }
    }
});

//return the model
module.exports = mongoose.model('Starter', StarterSchema);
