// grab the packages that we need for the user model
var mongoose = require('mongoose');
var schema = mongoose.Schema;

// pump schema
var CableSchema = new schema({
    body : {
        "hp": {
            type: Number
        },
        "length": {
            type: Number
        },
        "diameter": {                       // changed thickness to dia
            type: Number
        },
        "voltage": {                        // voltage rating of pump
            type: Number
        },
        "cost": {
            type: Number
        },

        "type": {
            type: String,
            default: "Cable"
        }
    }
});

//return the model
module.exports = mongoose.model('Cable', CableSchema);