var starter = require('../controllers/starter'); // changed from pump to cable

module.exports = function(app, express) {

    var apiRouter = express.Router();

    apiRouter.route('/starter')
        .get(starter.list)
        .post(starter.create);

    apiRouter.route('/starter/:starter_id')
        .get(starter.listOne)
        .put(starter.update)
        .delete(starter.remove);

    apiRouter.route('/starter/search')
        .post(starter.listSearch);

    return apiRouter;
};