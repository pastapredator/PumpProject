var cable = require('../controllers/cable'); // changed from pump to cable

module.exports = function(app, express) {

    var apiRouter = express.Router();

    apiRouter.route('/cable')
        .get(cable.list)
        .post(cable.create);

    apiRouter.route('/cable/:cable_id')
        .get(cable.listOne)
        .put(cable.update)
        .delete(cable.remove);

    apiRouter.route('/cable/search')
        .post(cable.listSearch);

    return apiRouter;
};/**
 * Created by Krishna on 10/19/2016.
 */
