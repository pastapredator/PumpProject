var pump = require('../controllers/pump');

module.exports = function(app, express) {

    var apiRouter = express.Router();

    apiRouter.route('/pumps')
        .get(pump.list)
        .post(pump.create);

    apiRouter.route('/pump/:pump_id')
        .get(pump.listOne)
        .put(pump.update)
        .delete(pump.remove);

    apiRouter.route('/pumps/search')
        .post(pump.listSearch);

    return apiRouter;
};