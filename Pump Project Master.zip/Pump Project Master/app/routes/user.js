var user = require('../controllers/user');
var pump = require('../controllers/pump');
var auth =  require('../controllers/authentication');


module.exports = function(app, express) {

    var apiRouter = express.Router();

    // route to authenticate a user (POST http://localhost:8080/api/authenticate)
    /*apiRouter.route('/authenticate')
        .post(auth.authenticate);

    apiRouter.use(auth.middle);*/

    apiRouter.route('/users')
        .get(user.list)
        .post(user.create);

    apiRouter.route('/users/:user_id')
        .get(user.listOne)
        .put(user.update)
        .delete(user.remove);

   /* apiRouter.route('/pumps')
        .get(pump.list)
        .post(pump.create);

    apiRouter.route('/pumps/:pump_id')
        .get(pump.listOne)
        .put(pump.update)
        .delete(pump.remove);
*/
    apiRouter.get('/', function(req, res){
        res.send({ message: 'hooray! Welcome to our api!' });
    });

    apiRouter.get('/me', function (req, res) {
        res.send(req.decoded);
    });

    // more routes for our API will happen here

    return apiRouter;
};