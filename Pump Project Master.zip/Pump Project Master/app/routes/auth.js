var auth =  require('../controllers/authentication');

module.exports = function(app, express) {


    var apiRouter = express.Router();

    // route to authenticate a user (POST http://localhost:8080/api/authenticate)
    apiRouter.route('/authenticate')
        .post(auth.authenticate);

    apiRouter.use(auth.middle);

    return apiRouter;
};


