angular.module('userApp', [
    'ngAnimate',
    'routerRoutes',
    'authService',
    'mainCtrl',
    'userCtrl',
    'userService',
    'pumpCtrl',
    'pumpService',
    'cableCtrl',
    'cableService',
    'starterCtrl',
    'starterService',

])
.config(function($httpProvider) {
    $httpProvider.interceptors.push('AuthInterceptor');
});
