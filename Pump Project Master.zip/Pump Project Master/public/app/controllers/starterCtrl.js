/**
 * Created by Krishna on 10/26/2016.
 */
// start our angular module and inject starterService
angular.module('starterCtrl', ['starterService'])

    // pump controller for the main page
    // inject the starter factory
    .controller('starterController', function(Starter) {

        var vm = this;

        // set a processing variable to show loading things
        vm.processing = true;
        vm.show = false;
        vm.noData=false;

        // grab all the pumps at page load
        Starter.all()
            .success(function(data) {

                // when all the pumps come back, remove the processing variable
                vm.processing = false;

                // bind the starter that come back to vm.starter
                vm.starter = data;
            });

        // function to delete a pump
        vm.deleteStarter = function(id) {
            vm.processing = true;

            // accepts the pump id as a parameter
            Starter.delete(id)
                .success(function(data) {

                    // get all pumps to update the table
                    // to return the list of pumps with the delete call
                    Starter.all()
                        .success(function(data) {
                            vm.processing = false;
                            vm.starter = data;
                        });
                });
        };

        vm.findStarter = function() {

            Starter.search(vm.starterData)
                .success(function(data) {
                    vm.show=false;
                    vm.processing = false;
                    if(!data.length>0)
                        vm.noData=true;
                    else vm.noData=false;
                    vm.starter = data;
                })
        };

        // more stuff to come soon
    })

    .controller('starterCreateController', function(Starter) {

        console.log('in create starter CTRL');

        var vm = this;

        // variable to hide/show elements of the view
        // differentiates between create or edit pages
        vm.type = 'create';

        // function to create a starter
        vm.saveStarter = function() {
            vm.processing = true;

            // clear the message
            vm.message = '';

            // use the create function in the pumpService
            Starter.create(vm.starterData)
                .success(function(data) {
                    vm.processing = false;

                    // clear the form
                    vm.starterData = {};
                    vm.message = data.message;
                });
        };
    })

    // controller applied to starter edit page
    .controller('starterEditController', function($routeParams, Starter) {

        var vm = this;

        // variable to hide/show elements of the view
        // differentiates between create or edit pages
        vm.type = 'edit';

        // get the starter data for the starter you want to edit
        // $routeParams is the way we grab data from the URL
        console.log($routeParams.starter_id);
        Starter.get($routeParams.starter_id)
            .success(function(data) {
                vm.starterData=data;
            });

        // function to save the starter
        vm.saveStarter = function() {
            vm.processing = true;
            vm.message='';


            // call the starter Service function to update
            Starter.update($routeParams.starter_id, vm.starterData)
                .success(function(data) {
                    vm.processing = false;

                    vm.starterData = data;
                    // clear the form


                    // bind the message from our API to vm.message
                    vm.message = data.message;
                });
        };

        vm.deleteStarter = function(id) {
            vm.processing = true;

            // accepts the starter id as a parameter
            Starter.delete(id)
                .success(function(data) {

                    // get all starter to update the table
                    // you can also set up your api
                    // to return the list of starter with the delete call
                    Starter.all()
                        .success(function(data) {
                            vm.processing = false;
                            vm.starter = data;
                        });
                });
        };

    });
