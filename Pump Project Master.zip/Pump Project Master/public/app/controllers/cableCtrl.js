// start our angular module and inject cableService
angular.module('cableCtrl', ['cableService']) // changing all Pump to cable now  - 10 /18/3PM

    // pump controller for the main page
    // inject the cable factory
    .controller('cableController', function(Cable) {

        var vm = this;

        // set a processing variable to show loading things
        vm.processing = true;
        vm.show = false;
        vm.noData=false;

        // grab all the pumps at page load
        Cable.all()
            .success(function(data) {

                // when all the pumps come back, remove the processing variable
                vm.processing = false;

                // bind the cables that come back to vm.cables 000 changed pumps to cable should it be cables ?
                vm.cable = data;
            });

        // function to delete a pump
        vm.deleteCable = function(id) {
            vm.processing = true;

            // accepts the pump id as a parameter
            Cable.delete(id)
                .success(function(data) {

                    // get all pumps to update the table
                    // to return the list of pumps with the delete call
                    Cable.all()
                        .success(function(data) {
                            vm.processing = false;
                            vm.cable = data;
                        });
                });
        };

        vm.findCable = function() {

            Cable.search(vm.cableData)  // cable data is not collection name ?
                .success(function(data) {
                    vm.show=false;
                    vm.processing = false;
                    if(!data.length>0)
                        vm.noData=true;
                    else vm.noData=false;
                    vm.cable = data; // changed pump 2 cable
                })
        };

        // more stuff to come soon
    })

    .controller('cableCreateController', function(Cable) {

        console.log('in create cable');

        var vm = this;

        // variable to hide/show elements of the view
        // differentiates between create or edit pages
        vm.type = 'create';

        // function to create a cable
        vm.saveCable = function() {
            vm.processing = true;

            // clear the message
            vm.message = '';

            // use the create function in the pumpService
            Cable.create(vm.cableData)
                .success(function(data) {
                    vm.processing = false;

                    // clear the form
                    vm.cableData = {};
                    vm.message = data.message;
                });
        };
    })

    // controller applied to cable edit page
    .controller('cableEditController', function($routeParams, Cable) {  // changed from pump to cable

        var vm = this;

        // variable to hide/show elements of the view
        // differentiates between create or edit pages
        vm.type = 'edit';

        // get the cable data for the cable you want to edit
        // $routeParams is the way we grab data from the URL
        console.log($routeParams.cable_id);
        Cable.get($routeParams.cable_id)
            .success(function(data) {
                vm.cableData=data;
            });

        // function to save the cable
        vm.saveCable = function() {
            vm.processing = true;
            vm.message='';


            // call the cableService function to update
            Cable.update($routeParams.cable_id, vm.cableData)
                .success(function(data) {
                    vm.processing = false;

                    vm.cableData = data;
                    // clear the form


                    // bind the message from our API to vm.message
                    vm.message = data.message;
                });
        };

        vm.deleteCable = function(id) {
            vm.processing = true;

            // accepts the cable id as a parameter
            Cable.delete(id)
                .success(function(data) {

                    // get all cable to update the table
                    // you can also set up your api
                    // to return the list of cable with the delete call
                    Cable.all()
                        .success(function(data) {
                            vm.processing = false;
                            vm.cable = data; // pumps inda changed
                        });
                });
        };

    });