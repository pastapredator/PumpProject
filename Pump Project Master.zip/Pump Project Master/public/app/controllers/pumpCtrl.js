// start our angular module and inject pumpService
angular.module('pumpCtrl', ['pumpService'])

    // pump controller for the main page
    // inject the Pump factory
    .controller('pumpController', function(Pump) {

        var vm = this;

        // set a processing variable to show loading things
        vm.processing = true;
        vm.show = false;
        vm.noData=false;

        // grab all the pumps at page load
        Pump.all()
            .success(function(data) {

                // when all the pumps come back, remove the processing variable
                vm.processing = false;

                // bind the pumps that come back to vm.pumps
                vm.pumps = data;
            });

        // function to delete a pump
        vm.deletePump = function(id) {
            vm.processing = true;

            // accepts the pump id as a parameter
            Pump.delete(id)
                .success(function(data) {

                    // get all pumps to update the table
                    // you can also set up your api
                    // to return the list of pumps with the delete call
                    Pump.all()
                        .success(function(data) {
                            vm.processing = false;
                            vm.pumps = data;
                        });
                });
        };

        vm.findPump = function() {

            Pump.search(vm.pumpData)
                .success(function(data) {
                   vm.show=false;
                    vm.processing = false;
                    if(!data.length>0)
                    vm.noData=true;
                    else vm.noData=false;
                    vm.pump =  data;
            })
        };

        // more stuff to come soon
    })

    .controller('pumpCreateController', function(Pump) {

        var vm = this;

        // variable to hide/show elements of the view
        // differentiates between create or edit pages
        vm.type = 'create';

        // function to create a pump
        vm.savePump = function() {
            vm.processing = true;

            // clear the message
            vm.message = '';

            vm.pumpData.properties.waterDischarge = Object.keys(vm.pumpData.properties.waterDischarge).map(function (key) {return vm.pumpData.properties.waterDischarge[key]})

            vm.pumpData.properties.headHeight_supported = Object.keys(vm.pumpData.properties.headHeight_supported).map(function (key) {return vm.pumpData.properties.headHeight_supported[key]});

            // use the create function in the pumpService
            Pump.create(vm.pumpData)
                .success(function(data) {
                    vm.processing = false;

                    // clear the form
                   vm.pumpData = {};
                    vm.message = data.message;
                });
        };
    })

    // controller applied to pump edit page
    .controller('pumpEditController', function($routeParams, Pump) {

        var vm = this;

        // variable to hide/show elements of the view
        // differentiates between create or edit pages
        vm.type = 'edit';

        // get the pump data for the pump you want to edit
        // $routeParams is the way we grab data from the URL
        console.log($routeParams.pump_id);
        Pump.get($routeParams.pump_id)
            .success(function(data) {
                vm.pumpData=data;
            });

        // function to save the pump
        vm.savePump = function() {
            vm.processing = true;
            vm.message='';

            vm.pumpData.properties.waterDischarge = Object.keys(vm.pumpData.properties.waterDischarge).map(function (key) {return vm.pumpData.properties.waterDischarge[key]});
            vm.pumpData.properties.headHeight_supported = Object.keys(vm.pumpData.properties.headHeight_supported).map(function (key) {return vm.pumpData.properties.headHeight_supported[key]});

            // call the pumpService function to update
            Pump.update($routeParams.pump_id, vm.pumpData)
                .success(function(data) {
                    vm.processing = false;

                    vm.pumpData =data;
                    // clear the form


                    // bind the message from our API to vm.message
                    vm.message = data.message;
                });
        };

        vm.deletePump = function(id) {
            vm.processing = true;

            // accepts the pump id as a parameter
            Pump.delete(id)
                .success(function(data) {

                    // get all pumps to update the table
                    // you can also set up your api
                    // to return the list of pumps with the delete call
                    Pump.all()
                        .success(function(data) {
                            vm.processing = false;
                            vm.pumps = data;
                        });
                });
        };

    });