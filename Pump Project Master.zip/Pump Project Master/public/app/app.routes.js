angular.module('routerRoutes', ['ngRoute'])

.config(function($routeProvider, $locationProvider) {

    $routeProvider

        // home page route
        .when('/', {
            templateUrl: 'app/views/pages/home.html'
        })

        // login page
        .when('/login', {
            templateUrl: 'app/views/pages/login.html',
            controller: 'mainController',
            controllerAs: 'login'
        })

        // show all users
        .when('/users', {
            templateUrl: 'app/views/pages/users/all.html',
            controller: 'userController',
            controllerAs: 'user'
        })

        // form to create a new user
        // same view as edit page
        .when('/users/create', {
            templateUrl: 'app/views/pages/users/single.html',
            controller: 'userCreateController',
            controllerAs: 'user'
        })

        // page to edit a user
        .when('/users/:user_id', {
            templateUrl: 'app/views/pages/users/single.html',
            controller: 'userEditController',
            controllerAs: 'user'
        })

        .when('/pumps', {
            templateUrl: 'app/views/pages/pumps/allPumps.html',
            controller: 'pumpController',
            controllerAs: 'pump'
        })

        // form to create a new user
        // same view as edit page
        .when('/pumps/create', {
            templateUrl: 'app/views/pages/pumps/singlePump.html',
            controller: 'pumpCreateController',
            controllerAs: 'pump'
        })

        // page to view a Pump
        .when('/pump/:pump_id', {
            templateUrl: 'app/views/pages/pumps/singlePump.html', // why is this block of code needed ?
            controller: 'pumpEditController',
            controllerAs: 'pump'
        })

        .when('/pump/view/:pump_id', {
            templateUrl: 'app/views/pages/pumps/viewPump.html', // is 'viewPump' different from 'singlepump' ? how ?
            controller: 'pumpEditController',
            controllerAs: 'pump'
        })

        .when('/pumps/search', {
            templateUrl: 'app/views/pages/pumps/findPump.html',
            controller: 'pumpController',
            controllerAs: 'pump'
        })
//cab-------------------------------------
        .when('/cable', {
            templateUrl: 'app/views/pages/cables/allCables.html',
            controller: 'cableController',
            controllerAs: 'cable'
        })

        // form to create a new user
        // same view as edit page
        .when('/cable/create', {
            templateUrl: 'app/views/pages/cables/singleCable.html',
            controller: 'cableCreateController',
            controllerAs: 'cable'
        })

        .when('/cable/search', {
            templateUrl: 'app/views/pages/cables/findCable.html',
            controller: 'cableController',
            controllerAs: 'cable'
        })



        .when('/cable/:cable_id', {
            templateUrl: 'app/views/pages/cables/singleCable.html',
            controller: 'cableEditController',
            controllerAs: 'cable'
        })



        .when('/cable/view/:cable_id', {
            templateUrl: 'app/views/pages/cables/viewCable.html',
            controller: 'cableEditController',
            controllerAs: 'cable'



        })
// starter ----------------------------------------------------
        .when('/starter', {
            templateUrl: 'app/views/pages/starters/allStarters.html',
            controller: 'starterController',
            controllerAs: 'starter'
        })

        // form to create a new user
        // same view as edit page
        .when('/starter/create', {
            templateUrl: 'app/views/pages/starters/singleStarter.html',
            controller: 'starterCreateController',
            controllerAs: 'starter'
        })

        .when('/starter/search', {
            templateUrl: 'app/views/pages/starters/findStarter.html',
            controller: 'starterController',
            controllerAs: 'starter'
        })


        .when('/starter/:starter_id', {
            templateUrl: 'app/views/pages/starters/singleStarter.html',
            controller: 'starterEditController',
            controllerAs: 'starter'
        })

        .when('/starter/view/:starter_id', {
            templateUrl: 'app/views/pages/starters/viewStarter.html',
            controller: 'starterEditController',
            controllerAs: 'starter'
        })


        .otherwise({
            redirectTo: 'app/views/index.html'
        });

    // get rid of # the has in the URL
    $locationProvider.html5Mode(true);
});

