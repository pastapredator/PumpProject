/**
 * Created by Krishna on 10/18/2016.
 */
angular.module('cableService', [])

    .factory('Cable', function($http) {

        // create the object
        var cableFactory = {};

        // get a single pump
        cableFactory.get = function(id) {
            return $http.get('/api/cable/' + id);
        };

        // get all pumps
        cableFactory.all = function() {
            return $http.get('/api/cable');
        };

        // create a pump
        cableFactory.create = function(cableData) {
            return $http.post('/api/cable', cableData);
        };

        // update a pump
        cableFactory.update = function(id, cableData) {
            return $http.put('/api/cable/' + id, cableData);
        };

        // delete a pump
        cableFactory.delete = function(id) {
            return $http.delete('/api/cable/' + id);
        };

        cableFactory.search = function(cableData) {
            return $http.post('/api/cable/search', cableData);
        };

        // return our entire pumpFactory object
        return cableFactory;

    });