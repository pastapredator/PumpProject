/**
 * Created by Krishna on 10/26/2016.
 */
angular.module('starterService', [])

    .factory('Starter', function($http) {

        // create the object
        var starterFactory = {};

        // get a single starter
        starterFactory.get = function(id) {
            return $http.get('/api/starter/' + id);
        };

        // get all starter
        starterFactory.all = function() {
            return $http.get('/api/starter');
        };

        // create a starter
        starterFactory.create = function(starterData) {
            return $http.post('/api/starter', starterData);
        };

        // update a starter
        starterFactory.update = function(id, starterData) {
            return $http.put('/api/starter/' + id, starterData);
        };

        // delete a starter
        starterFactory.delete = function(id) {
            return $http.delete('/api/starter/' + id);
        };

        starterFactory.search = function(starterData) {
            return $http.post('/api/starter/search', starterData);
        };

        // return our entire starterFactory object
        return starterFactory;

    });