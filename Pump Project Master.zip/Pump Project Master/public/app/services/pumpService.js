angular.module('pumpService', [])

    .factory('Pump', function($http) {

        // create the object
        var pumpFactory = {};

        // get a single pump
        pumpFactory.get = function(id) {
            return $http.get('/api/pump/' + id);
        };

        // get all pumps
        pumpFactory.all = function() {
            return $http.get('/api/pumps');
        };

        // create a pump
        pumpFactory.create = function(pumpData) {
            return $http.post('/api/pumps', pumpData);
        };

        // update a pump
        pumpFactory.update = function(id, pumpData) {
            return $http.put('/api/pump/' + id, pumpData);
        };

        // delete a pump
        pumpFactory.delete = function(id) {
            return $http.delete('/api/pump/' + id);
        };

        pumpFactory.search = function(pumpData) {
            return $http.post('/api/pumps/search', pumpData);
        };

        // return our entire pumpFactory object
        return pumpFactory;

    });