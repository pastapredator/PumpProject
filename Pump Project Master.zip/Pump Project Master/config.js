module.exports = {
    'port': process.env.PORT || 8080,
    'database': 'mongodb://localhost:27017/pumpdata',
    'secret': 'meanmachinesecret'
};